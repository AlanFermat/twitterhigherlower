
## About

twitter-likes-who is a web-game, where the player guesses which of two famous twitter users has more likes. Each time the player makes a correct guess, he scores a point. The game ends as long as the player makes a incorrect guess. We collect data from twitter real time and use a bootstrap framework for the website.
